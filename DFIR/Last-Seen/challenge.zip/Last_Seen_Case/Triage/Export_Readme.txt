Export Readme
-------------
This package is a working copy of selected MacBook-side backup material.
All backup directories preserve the hashed-file layout used by Apple local backups.
Use the backup metadata and Manifest.db in each root to resolve original artifact paths.
