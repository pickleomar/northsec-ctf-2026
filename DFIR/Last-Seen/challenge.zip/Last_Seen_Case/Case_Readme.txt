Last Seen
=========

Badr disappeared on the evening of January 1, 2025 after telling a friend he was heading to meet someone near Café Hafa in Tangier.

Police seized his MacBook and recovered a working copy of:
~/Library/Application Support/MobileSync/Backup

The backup directory contains multiple legitimate Apple-device backups.

Your task is to:
1. identify Badr's current iPhone backup
2. determine who he was coordinating with
3. identify the Wi-Fi network joined at the meetup
4. identify the answered cellular call tied to the coordinator after arrival
5. identify the first Safari search after that call
6. submit the final result as a hash

Build the final string in this exact format:
Device|Contact|SSID|CallTime|PostCallSearch

Where:
- Device = the exact current device name
- Contact = the resolved first name of the coordinator
- SSID = the exact Wi-Fi SSID joined at the meetup
- CallTime = the exact UTC timestamp of the answered cellular call tied to the coordinator after arrival, formatted as YYYY-MM-DDTHH:MM:SSZ
- PostCallSearch = the exact Safari search title after that call

Final flag format:
NSC{sha256(Device|Contact|SSID|CallTime|PostCallSearch)}

All timestamps should be treated as UTC.
